The **Maven** plugin contains views and directives that interact with Maven repositories

## Maven widgets
<div ng-include="'app/maven/html/test.html'"></div>
