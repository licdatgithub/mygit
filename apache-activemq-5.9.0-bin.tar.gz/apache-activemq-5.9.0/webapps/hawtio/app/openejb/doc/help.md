### OpenEJB

The OpenEJB plugin in [hawtio](http://hawt.io "hawtio") gives a raw view of the underlying OpenEJB JMX metric data.

This plugin works similar to the [JMX](#/help/jmx) plugin, where you can find more details about navigating the JMX tree,
and reading the attributes and invoking operations.

