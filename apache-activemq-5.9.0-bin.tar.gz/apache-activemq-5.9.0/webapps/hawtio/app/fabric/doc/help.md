### Fabric

This plugin works with [Fuse Fabric](http://fuse.fusesource.org/fabric/) to allow you to provision and configure clusters of [JBoss Fuse](http://www.jboss.org/jbossfuse) and introspect the running cluster.

Note that currently this plugin requires  [JBoss Fuse](http://www.jboss.org/jbossfuse) 6.1 or later. For earlier versions of Fuse, hawtio works great for Camel, ActiveMQ, OSGi, JMX and so forth; but hawtio requires the new JMX MBean in version 6.1 of Fuse Fabric to enable the Fabric plugin.