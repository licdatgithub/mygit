### Tomcat

This plugin works with Tomcat or TomEE to manage the deployed applications, as well viewing information about connectors, sessions and JMX, etc.

